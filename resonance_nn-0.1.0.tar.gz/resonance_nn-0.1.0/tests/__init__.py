"""Test suite for Spectral Neural Networks"""
